import fs from 'node:fs/promises'
import path from 'node:path'
import ts from 'typescript'

export const PLUGIN_JSX_OPTIONS = { jsx: 'transform', jsxFactory: 'React.createElement', jsxFragment: 'React.Fragment' }

const ignored = new Set(['node_modules', '.git', 'runtime', 'dist', 'out', 'out-tsc', 'vendor'])
export async function sourceFiles(root) {
  const files = []
  for (const entry of await fs.readdir(root, { withFileTypes: true })) {
    if (/claude/i.test(entry.name) || entry.name.startsWith('.plugin-build-') || ignored.has(entry.name) || entry.isSymbolicLink()) continue
    const file = path.join(root, entry.name)
    if (entry.isDirectory()) files.push(...await sourceFiles(file))
    else if (/\.[cm]?[jt]sx?$/.test(file)) files.push(file)
  }
  return files
}

export async function checkPlugin(root) {
  const pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'))
  const manifest = JSON.parse(await fs.readFile(path.join(root, 'manifest.json'), 'utf8'))
  const config = JSON.parse(await fs.readFile(path.join(root, 'config.json'), 'utf8'))
  if (manifest.apiVersion !== 4 || pkg.version !== manifest.version) throw new Error('Package and manifest must agree on version and apiVersion 4')
  if (config.main !== 'runtime/index.js') throw new Error('config.main must be runtime/index.js')
  if (config.assets && config.assets !== 'runtime/assets') throw new Error('config.assets must be runtime/assets')
  const dependencies = new Set(Object.keys({ ...pkg.dependencies, ...pkg.devDependencies, ...pkg.peerDependencies }))
  for (const file of await sourceFiles(root)) {
    const code = await fs.readFile(file, 'utf8')
    const tree = ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true)
    const inspect = (node) => {
      const specifier = (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) ? node.moduleSpecifier
        : ts.isCallExpression(node) && (node.expression.kind === ts.SyntaxKind.ImportKeyword || node.expression.getText(tree) === 'require') ? node.arguments[0] : null
      if (specifier && ts.isStringLiteral(specifier)) {
        const name = specifier.text
        if (/^@(shared|renderer|testing)(\/|$)/.test(name)) throw new Error(`${file}: host import ${name}`)
        if (name.startsWith('.')) {
          const relative = path.relative(root, path.resolve(path.dirname(file), name))
          if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error(`${file}: import escapes package: ${name}`)
        } else if (!name.startsWith('node:')) {
          const dependency = name.startsWith('@') ? name.split('/').slice(0, 2).join('/') : name.split('/')[0]
          if (!dependencies.has(dependency) && !['fs', 'path', 'os', 'url', 'fs/promises'].includes(name)) throw new Error(`${file}: undeclared dependency ${dependency}`)
        }
      }
      if (ts.isPropertyAccessExpression(node) && node.expression.getText(tree) === 'window' && node.name.text === 'valley') throw new Error(`${file}: use the injected API`)
      ts.forEachChild(node, inspect)
    }
    inspect(tree)
  }
  return { pkg, manifest, config }
}

export async function buildPlugin({ root = process.cwd(), outDir = path.join(root, 'runtime'), mode = 'production' } = {}) {
  const { build } = await import('esbuild')
  root = await fs.realpath(root)
  const { pkg, config } = await checkPlugin(root)
  const temporary = await fs.mkdtemp(path.join(path.dirname(outDir), '.plugin-build-'))
  try {
    const custom = pkg.valley?.build ? (await import(path.join(root, pkg.valley.build))).default : {}
    const options = typeof custom === 'function' ? await custom({ root, outDir: temporary }) : custom
    const result = await build({
      absWorkingDir: root, entryPoints: [path.join(root, 'src/index.tsx')], outfile: path.join(temporary, 'index.js'),
      bundle: true, format: 'esm', platform: 'browser', target: 'es2020', ...PLUGIN_JSX_OPTIONS, conditions: ['production'],
      loader: { '.css': 'text' }, metafile: true, minify: mode === 'production', logLevel: 'silent', ...options
    })
    if (result.warnings.length) throw new Error(result.warnings.map((warning) => warning.text).join('\n'))
    for (const input of Object.keys(result.metafile.inputs)) {
      const resolved = await fs.realpath(path.resolve(root, input))
      const relative = path.relative(root, resolved)
      if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error(`Bundle input escapes package: ${input}`)
    }
    if (config.assets) await fs.access(path.join(temporary, 'assets'))
    if (!config.build?.bundleReact && Object.keys(result.metafile.inputs).some((file) => /node_modules\/react(-dom)?\//.test(file))) throw new Error('Bundle contains React; use api.React')
    await replaceDirectory(temporary, outDir)
    return { outDir, metafile: result.metafile }
  } finally { await fs.rm(temporary, { recursive: true, force: true }) }
}

export async function replaceDirectory(staged, destination) {
  const backup = `${staged}.previous`
  let backedUp = false
  try { await fs.rename(destination, backup); backedUp = true } catch (error) { if (error.code !== 'ENOENT') throw error }
  try { await fs.rename(staged, destination) } catch (error) {
    if (backedUp) {
      try { await fs.rename(backup, destination) } catch (restoreError) {
        throw new AggregateError([error, restoreError], `Runtime replacement and restoration failed; previous runtime preserved at ${backup}`)
      }
    }
    throw error
  }
  if (backedUp) await fs.rm(backup, { recursive: true, force: true })
}
